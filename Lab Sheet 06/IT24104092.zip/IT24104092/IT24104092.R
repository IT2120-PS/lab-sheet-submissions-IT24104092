setwd("C:\\Users\\acer\\Desktop\\IT24104092")
#Exercise 
#Q1

#1)
0.85

#2)
dbinom(47,50,0.85)

#Q2

#1)

# X=number of customer calls received in a given time period

#2)
12

#3)
dpois(15,12)
